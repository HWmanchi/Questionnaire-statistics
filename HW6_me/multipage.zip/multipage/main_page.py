# https://docs.streamlit.io/library/get-started/multipage-apps
import streamlit as st

st.markdown("# Main page 🎈")
st.sidebar.markdown("# Main page 🎈")